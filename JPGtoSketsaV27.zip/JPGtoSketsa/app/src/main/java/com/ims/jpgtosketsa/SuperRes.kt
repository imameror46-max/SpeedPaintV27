package com.ims.jpgtosketsa

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import android.content.Context
import android.graphics.Bitmap
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min

/**
 * Super-resolusi AI offline (Real-ESRGAN general x4v3, BSD-3, sekitar 5 MB).
 * Foto kecil diperbesar 4x dengan detail baru (mata, rambut, tekstur) sebelum disketsa.
 */
object SuperRes {
    private const val ASSET = "sr_x4.onnx"
    private const val TILE = 160
    private const val PAD = 12

    private var appCtx: Context? = null
    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null

    private var cacheKey = 0L
    private var cacheBmp: Bitmap? = null

    @Volatile var lastError: String = ""

    fun init(c: Context) { appCtx = c.applicationContext }

    private fun ensureSession(): OrtSession {
        session?.let { return it }
        val ctx = appCtx ?: throw IllegalStateException("SuperRes belum diinisialisasi")
        val bytes = ctx.assets.open(ASSET).use { it.readBytes() }
        val e = OrtEnvironment.getEnvironment()
        val so = OrtSession.SessionOptions()
        so.setIntraOpNumThreads(4)
        val s = e.createSession(bytes, so)
        env = e
        session = s
        return s
    }

    private fun keyOf(src: Bitmap): Long {
        var k = src.width * 31L + src.height
        val w = src.width
        val h = src.height
        for (j in 0 until 16) for (i in 0 until 16) {
            k = k * 1000003L + src.getPixel((i * 2 + 1) * (w - 1) / 32, (j * 2 + 1) * (h - 1) / 32)
        }
        return k
    }

    /** Perbesar 4x. null jika model tidak ada atau gagal (lihat lastError). */
    @Synchronized
    fun upscale4(src: Bitmap): Bitmap? {
        return try {
            val key = keyOf(src)
            val cached = cacheBmp
            if (cached != null && key == cacheKey) return cached

            val sess = ensureSession()
            val e = env!!
            val w = src.width
            val h = src.height
            val px = IntArray(w * h)
            src.getPixels(px, 0, w, 0, 0, w, h)
            val ow = w * 4
            val oh = h * 4
            val out = IntArray(ow * oh)
            val inName = sess.inputNames.first()

            var ty = 0
            while (ty < h) {
                var tx = 0
                while (tx < w) {
                    val x1 = min(w, tx + TILE)
                    val y1 = min(h, ty + TILE)
                    val ex0 = max(0, tx - PAD)
                    val ey0 = max(0, ty - PAD)
                    val ex1 = min(w, x1 + PAD)
                    val ey1 = min(h, y1 + PAD)
                    val tw = ex1 - ex0
                    val th = ey1 - ey0

                    val fb = ByteBuffer.allocateDirect(3 * tw * th * 4).order(ByteOrder.nativeOrder()).asFloatBuffer()
                    val plane = tw * th
                    for (y in 0 until th) for (x in 0 until tw) {
                        val c = px[(ey0 + y) * w + ex0 + x]
                        fb.put(y * tw + x, ((c shr 16) and 255) / 255f)
                        fb.put(plane + y * tw + x, ((c shr 8) and 255) / 255f)
                        fb.put(2 * plane + y * tw + x, (c and 255) / 255f)
                    }
                    fb.rewind()
                    val tensor = OnnxTensor.createTensor(e, fb, longArrayOf(1, 3, th.toLong(), tw.toLong()))
                    val res = sess.run(mapOf(inName to tensor))
                    val ob = (res.get(0) as OnnxTensor).floatBuffer
                    val ptw = tw * 4
                    val oplane = ptw * th * 4
                    for (y in ty until y1) for (x in tx until x1) {
                        for (dy in 0 until 4) for (dx in 0 until 4) {
                            val sy = (y - ey0) * 4 + dy
                            val sx = (x - ex0) * 4 + dx
                            val r = (ob.get(sy * ptw + sx).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                            val g = (ob.get(oplane + sy * ptw + sx).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                            val b = (ob.get(2 * oplane + sy * ptw + sx).coerceIn(0f, 1f) * 255f + 0.5f).toInt()
                            out[(y * 4 + dy) * ow + x * 4 + dx] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                        }
                    }
                    res.close()
                    tensor.close()
                    tx += TILE
                }
                ty += TILE
            }
            val bmp = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
            bmp.setPixels(out, 0, ow, 0, 0, ow, oh)
            cacheBmp = bmp
            cacheKey = key
            lastError = ""
            bmp
        } catch (t: Throwable) {
            lastError = t.javaClass.simpleName + ": " + (t.message ?: "")
            null
        }
    }
}
